import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class NoteActivity : AppCompatActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_note)

    val noteText = findViewById<TextView>(R.id.note_text)
    noteText.text = "Notes: A, B, C, D, E, F, G"

    val noteImage = findViewById<ImageView>(R.id.note_image)
    noteImage.setImageResource(R.drawable.note_image)

    val playNoteButton = findViewById<Button>(R.id.play_note_button)
    playNoteButton.setOnClickListener { playNote() }
  }

  private fun playNote() {
    val mediaPlayer = MediaPlayer.create(this, R.raw.note_sound)
    mediaPlayer.start()
  }
}
