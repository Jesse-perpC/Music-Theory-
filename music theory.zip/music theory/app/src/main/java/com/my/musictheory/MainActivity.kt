package com.my.musictheory

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

  private lateinit var noteButton: Button
  private lateinit var chordButton: Button
  private lateinit var scaleButton: Button
  private lateinit var theoryText: TextView
  private lateinit var earTrainingButton: Button
  private lateinit var musicHistoryButton: Button
  private lateinit var playButton: Button
  private lateinit var pauseButton: Button
  private lateinit var musicImageView: ImageView

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    noteButton = findViewById(R.id.note_button)
    chordButton = findViewById(R.id.chord_button)
    scaleButton = findViewById(R.id.scale_button)
    theoryText = findViewById(R.id.theory_text)
    earTrainingButton = findViewById(R.id.ear_training_button)
    musicHistoryButton = findViewById(R.id.music_history_button)
    playButton = findViewById(R.id.play_button)
    pauseButton = findViewById(R.id.pause_button)
    musicImageView = findViewById(R.id.music_image_view)

    noteButton.setOnClickListener {
      val intent = Intent(this, NoteActivity::class.java)
      startActivity(intent)
    }

    chordButton.setOnClickListener {
      val intent = Intent(this, ChordActivity::class.java)
      startActivity(intent)
    }

    scaleButton.setOnClickListener {
      val intent = Intent(this, ScaleActivity::class.java)
      startActivity(intent)
    }

    earTrainingButton.setOnClickListener {
      val intent = Intent(this, EarTrainingActivity::class.java)
      startActivity(intent)
    }

    musicHistoryButton.setOnClickListener {
      val intent = Intent(this, MusicHistoryActivity::class.java)
      startActivity(intent)
    }

    playButton.setOnClickListener { playMusic() }

    pauseButton.setOnClickListener { pauseMusic() }

    musicImageView.setOnClickListener { showMusicImage() }
  }

  private fun playMusic() {
    val mediaPlayer = MediaPlayer.create(this, R.raw.music)
    mediaPlayer.start()
  }

  private fun pauseMusic() {
    val mediaPlayer = MediaPlayer.create(this, R.raw.music)
    mediaPlayer.pause()
  }

  private fun showMusicImage() {
    musicImageView.setImageResource(R.drawable.music_image)
  }
}

// (I added the following features:

// - A play button to play music
// - A pause button to pause music
// - An image view to display a music-related image
// - A music image view that changes color when clicked
// - A fun fact text view that displays random music-related facts
// - A "Did You Know" button that displays a random music-related fact when clicked
// - A "Music Quiz" button that launches a music quiz activity
// - A "Music Games" button that launches a music games activity
